import requests
import math

# first menu
def firstMenu():
    print("Welcome to the ticket viewer")
    firstOption = input("type 'menu' to view options, or 'quit' to exit\n")
    if firstOption == 'menu':
        secondMenu()
    elif firstOption == 'quit':
        exit(0)
    else:
        print("incorrect input, please try again")
        input("type anything to continue\n")
        firstMenu()

# second menu
def secondMenu():
    print("Select view options:")
    print("* Press 1 to view all tickets")
    print("* Press 2 to view a ticket")
    print("* Type 'quit' to exit")
    secondOption = input()
    if secondOption == '1':
        getAllTickets()
    elif secondOption == '2':
        getOneTicket()
    elif secondOption == 'quit':
        exit(0)
    else:
        print("incorrect input, please try again")
        input("type anything to continue\n")
        secondMenu()

def thirdMenu(target_page, pages):
    t_page = target_page
    print("\nSelect view options:")
    print("* Press 1 to view previous page")
    print("* Press 2 to view next page")
    print("* Type 'back' to go to the previous menu")
    option = input()
    if option == '1':
        # if it is not the first page
        if t_page > 0:
            t_page -= 1
        else:
            print('Sorry this is the first page, please try again')
            input("type anything to continue\n")
            thirdMenu(t_page, pages)
    elif option == '2':
        if t_page < pages - 1:
            t_page += 1
        else:
            print('Sorry this is the last page, please try again')
            input("type anything to continue\n")
            thirdMenu(t_page, pages)
    elif option == 'back':
        secondMenu()
    else:
        print("incorrect input, please try again")
        input("type anything to continue\n")
        thirdMenu(t_page, pages)
    return t_page

# get all tickets in json
def getAllTickets ():
    session = requests.Session()
    # user name and password
    session.auth = ('zichangren.work@gmail.com', '123qweasdzxc')
    tickets_response = session.get('https://zichangren.zendesk.com/api/v2/tickets.json?include=comment_count')
    # get response code of getting tickets request
    tickets_res_code = tickets_response.status_code
    # connect successfully
    if tickets_res_code == 200:
        try:
            # tickets_response.json()['tickets'] is a list of tickets
            tickets = tickets_response.json()['tickets']
            # calculate ticket number and page number
            tickets_count = len(tickets)
            pages = int(math.ceil(tickets_count / 25))
            # to store tickets of every page
            page_tickets = []
            # initialize index
            index = 0
            # put every 25 tickets in a list and put the list in page_tickets
            for ticket in tickets:
                # if it should be a new page
                if index % 25 == 0:
                    # empty tickets list
                    tickets_list = []
                # put ticket in
                tickets_list.append(ticket)
                # if it is the last of the page or the last ticket
                # put tickets_list in page_tickets
                if ((index + 1) % 25 == 0) | (index + 1 == tickets_count):
                    page_tickets.append(tickets_list)
                index += 1
            # close connection
            session.close()
            print('Retrieved ' + str(tickets_count) + ' tickets successfully\n')
            target_page = 0
            while 1:
                print('Now showing page ' + str(target_page + 1) + '/' + str(pages) + ', 25 records in this page\n')
                for ticket in page_tickets[target_page]:
                    # print ticket
                    print('*ticket id:* ' + str(ticket['id'])
                          + ' *subject:* ' + str(ticket['subject'])
                          + ' *created time:* ' + str(ticket['created_at'])
                          + ' *updated time:* ' + str(ticket['updated_at'])
                          + ' *submitter id:* ' + str(ticket['submitter_id'])
                          + ' *assignee id:* ' + str(ticket['assignee_id']))
                target_page = thirdMenu(target_page, pages)

        # if json file key does not match
        except KeyError:
            print('An error has occurred while fetching the tickets')
            input("type anything to continue\n")
            secondMenu()
    # if not build connection
    else:
        print('Fail to retrieve all tickets')
        input("type anything to continue\n")
        secondMenu()

def getOneTicket():
    id = input('Please input the id of the ticket you want to retrieve\n')
    session = requests.Session()
    # user name and password
    session.auth = ('zichangren.work@gmail.com', '123qweasdzxc')
    tickets_response = session.get('https://zichangren.zendesk.com/api/v2/tickets/' + id + '.json?include=comment_count')
    # get response code of getting tickets request
    tickets_res_code = tickets_response.status_code
    # connect successfully
    if tickets_res_code == 200:
        try:
            ticket = tickets_response.json()['ticket']
            print('*ticket id:* ' + str(ticket['id'])
                  + '\n*subject:* ' + str(ticket['subject'])
                  + '\n*created time:* ' + str(ticket['created_at'])
                  + '\n*updated time:* ' + str(ticket['updated_at'])
                  + '\n*submitter id:* ' + str(ticket['submitter_id'])
                  + '\n*assignee id:* ' + str(ticket['assignee_id'])
                  + '\n*Content*: \n' + str(ticket['description']))
            session.close()
            secondMenu()
        except KeyError:
            print('An error has occurred while fetching ticket #' + id)
            input("type anything to continue\n")
            secondMenu()
    # if not build connection
    else:
        print('Fail to retrieve ticket #' + id)
        input("type anything to continue\n")
        secondMenu()

def main():
    firstMenu()

if __name__ == "__main__":
    main()
